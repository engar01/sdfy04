class Plata:
    def bgbgbgbg(self):
        print('bgbgbgbgb')

    def __init__(self):
        super().__init__()
        self.model = 'MRX'

class Display:
    def Photo_print(self):
        print('Print photo')

    def __init__(self):
        super().__init__()
        self.Diss_model = '15K'

class Comuter(Plata, Display):
    def print(self):
        super().__init__()
        print('I have a Display and a plata:')
        print(self.Diss_model)
        print(self.model)


hp = Comuter()
hp.print()