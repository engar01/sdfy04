import random


class Apple:
    def __init__(self):
        self.number = int(input('Впишіть число:) :'))
        if self.number <= 1:
            print('Число повинно бути більше 1 :)')
            self.number
        self.__Chpunk()

    def __Chpunk(self):
        die = random.randint(1, 4)
        if die == 1:
            print(self.number ** 2)
        if die == 2:
            print(self.number // 2)
        if die == 3:
            print(self.number + +2)
        if die == 4:
            print(self.number - -2)


A = Apple()
